sap.ui.define([
	"com/org/excelupload/uploadXl/test/unit/controller/View1.controller"
], function () {
	"use strict";
});